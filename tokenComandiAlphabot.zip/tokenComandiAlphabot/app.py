from flask import Flask, render_template, request, redirect, url_for, make_response
import sqlite3 as sql
from werkzeug.security import generate_password_hash, check_password_hash
import socket

app = Flask(__name__)
global username_global

@app.route("/home", methods=["GET"])
def home():
    global username_global
    if request.cookies.get('accesso_cookie'):
        username_global = request.cookies.get('accesso_cookie')
    return render_template("home.html", username=username_global)


@app.route("/", methods=["GET", "POST"])
def login():
    if request.cookies.get('accesso_cookie'):
        return redirect(url_for("home"))
    else: 
        if request.method == "POST":
            email = request.form["e-mail"]
            password = request.form["password"]
            return validate(email, password)
        return render_template("login.html")


@app.route("/create_account", methods=["GET", "POST"])
def create_account():
    if request.method == "POST":
        email = request.form["e-mail"]
        password = request.form["password"]
        conn = sql.connect("users.db")
        cur = conn.cursor()
        cur.execute(f"""SELECT 1
                        FROM users
                        WHERE email LIKE '{email}'""")
        user = cur.fetchone()
        if user == None:
            cur.execute(f"""INSERT INTO users (email, password)
                            VALUES ('{email}', '{generate_password_hash(password)}')""")
            conn.commit()
            conn.close()
            return redirect(url_for("login"))
        else:
            # utente già esistente
            pass
    return render_template("create_account.html")


@app.route("/logout")
def logout():
    resp = redirect(url_for("login"))
    resp.set_cookie('accesso_cookie', '', expires=0)
    return resp

def validate(username, password):
    global username_global
    conn = sql.connect("users.db")
    cur = conn.cursor()
    cur.execute(f"""SELECT users.password
                    FROM users
                    WHERE email LIKE '{username}'""")
    pswd = cur.fetchone()
    if pswd and check_password_hash(pswd[0], password):
        username_global = username
        resp = redirect(url_for("home"))
        resp.set_cookie('accesso_cookie', username, max_age=60*60*24)
        return resp
    return render_template("login.html", alert="Invalid credentials")

@app.route("/control", methods=["GET", "POST"])
def control():
    global username_global
    if not request.cookies.get('accesso_cookie'):
        return redirect(url_for("login"))

    return render_template("control.html", username=username_global)


def invia_comando_alphabot(comando):
    server_ip = "192.168.1.151"  # L'IP del robot
    server_port = 22222  # La porta di connessione
    client_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client_tcp.connect((server_ip, server_port))
        client_tcp.send(comando.encode('utf-8'))
    except Exception as e:
        print(f"Errore nel connettersi al robot: {e}")
    finally:
        client_tcp.close()


@app.route("/move/<direction>", methods=["POST"])
def move(direction):
    # Invia il comando di movimento al robot tramite socket
    invia_comando_alphabot(direction)
    return '', 200  # Risposta vuota, 200 OK


@app.route("/move/stop", methods=["POST"])
def stop():
    # Invia il comando di stop al robot
    invia_comando_alphabot('stop')
    return '', 200  # Risposta vuota, 200 OK



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=4444)
